package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class SymdTask {
	

	    WebDriver driver;

	    @BeforeClass
	    public void setup() {
	        // Initialize the WebDriver and open the URL
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://d3pv22lioo8876.cloudfront.net/tiptop/");
	    }

	    @Test(priority = 1)
	    public void verifyDisabledInput() {
	        // Verify that the input is disabled
	        WebElement disabledInput = driver.findElement(By.xpath("(//input[@name='my-disabled'])[1]"));
	        Assert.assertFalse(disabledInput.isEnabled(), "Input is not disabled");
	    }

	    @Test(priority = 2)
	    public void verifyReadonlyInput() {
	        // Verify readonly input using two xpaths
	        WebElement readonlyInput1 = driver.findElement(By.xpath("//input[@value='Readonly input']"));
	        WebElement readonlyInput2 = driver.findElement(By.xpath("//input[@readonly and @value='Readonly input']"));

	        Assert.assertTrue(readonlyInput1.getAttribute("readonly").equals("true"), "Input is readonly with 1st xpath");
	        Assert.assertTrue(readonlyInput2.getAttribute("readonly").equals("true"), "Input is readonly (2nd XPath)");
	    }

	    @Test(priority = 3)
	    public void verifyDropdownElements() {
	        // Verify the dropdown has 8 elements using two xpaths
	        WebElement dropdown = driver.findElement(By.xpath("//select[@name='my-select']"));
	        List<WebElement> options1 = dropdown.findElements(By.tagName("option"));
	        Assert.assertEquals(options1.size(), 8, "Dropdown have 8 options using 1st Xpath");

	        List<WebElement> options2 = driver.findElements(By.xpath("//select[@name=' my-select']/option"));
	        Assert.assertEquals(options2.size(), 8, "Dropdown does 8 options using 2nd xpath");
	    }

	    @Test(priority = 4)
	    public void verifySubmitButtonDisabled() {
	        // Verify the submit button is disabled when the Name field is empty
	        WebElement submitButton = driver.findElement(By.xpath("//button[@type='submit']"));
	        Assert.assertFalse(submitButton.isEnabled(), "Submit button is disabled when Name & password field is empty");
	    }

	    @Test(priority = 5)
	    public void verifySubmitButtonEnabledwithNameAndPassword() {
	        // Verify the submit button is enabled when Name and Password fields are filled
	        WebElement nameInput = driver.findElement(By.xpath("//input[@name='my-name']"));
	        WebElement passwordInput = driver.findElement(By.xpath("//input[@name='my-password']"));
	        WebElement submitButton = driver.findElement(By.xpath("//button[@type='submit']"));

	        nameInput.sendKeys("Naveen");
	        passwordInput.sendKeys("N@veen");

	        Assert.assertTrue(submitButton.isEnabled(), "Submit button is  enabled after filling Name and Password");
	    }

	    @Test(priority = 6)
	    public void verifySubmitDisplaysReceivedText() {
	        // Verify the page shows "Received" text upon submission
	        WebElement submitButton = driver.findElement(By.xpath("//button[@type='submit']"));
	        submitButton.click();

	        WebElement receivedText = driver.findElement(By.xpath("//p[contains(text(), 'Received')]"));
	        Assert.assertEquals(receivedText.getText(), "Received", "'Received' text not displayed after submission");
	    }

	    @Test(priority = 7)
	    public void verifyFormDataInURL() {
	        // Verify all form data is passed to the URL
	        String currentUrl = driver.getCurrentUrl();
	        Assert.assertTrue(currentUrl.contains("name=Naveen"), "Name data  passed in URL");
	        Assert.assertTrue(currentUrl.contains("password=N@veen"), "Password data passed in URL");
            Assert.assertTrue(currentUrl.contains("my-readonly=Readonly"), "Readonly field data  passed in URL");
	        Assert.assertTrue(currentUrl.contains("my-select=white"), "Select color data passed in URL");

	    }

	  
		@AfterClass
	    public void tearDown() {
	        // Close the browser
	        if (driver != null) {
	            driver.quit();
	        }
	    }
	}

